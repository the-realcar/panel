# SECURITY - Polityka bezpieczeństwa

## Bezpieczeństwo projektu

Panel Pracowniczy Firma KOT implementuje najlepsze praktyki bezpieczeństwa dla aplikacji webowych.

## Zaimplementowane mechanizmy bezpieczeństwa

### 1. Autentykacja i autoryzacja

- **Hashowanie haseł**: bcrypt z kosztami 10
- **Session management**: Timeout 30 minut nieaktywności
- **RBAC**: Role-Based Access Control z granularnymi uprawnieniami
- **Regeneracja Session ID**: Po każdym logowaniu

```php
// Hashowanie haseł
$password_hash = password_hash($password, PASSWORD_BCRYPT);

// Weryfikacja
if (password_verify($password, $password_hash)) {
    // Poprawne hasło
}
```

### 2. Ochrona przed atakami

#### SQL Injection
- Wszystkie zapytania DB używają prepared statements (PDO)
- Parametryzowane zapytania

```php
// ✓ Bezpieczne
$db->execute("SELECT * FROM users WHERE id = :id", [':id' => $id]);

// ✗ Niebezpieczne (NIE RÓB!)
$db->execute("SELECT * FROM users WHERE id = $id");
```

#### Cross-Site Scripting (XSS)
- `htmlspecialchars()` na wszystkich wyjściach HTML
- Funkcja `e()` do escapowania

```php
// ✓ Bezpieczne
<?php echo e($user_input); ?>

// ✗ Niebezpieczne (NIE RÓB!)
<?php echo $user_input; ?>
```

#### Cross-Site Request Forgery (CSRF)
- Tokeny CSRF w formularzach
- Walidacja tokenów przed przetworzeniem

```php
// W formularzu
<?php echo csrfField(); ?>

// W kontrolerze
if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    setFlashMessage('error', 'Nieprawidłowy token CSRF');
    redirect('/');
}
```

### 3. Sesje

```php
// config/session.php
ini_set('session.cookie_httponly', 1);      // Session only w HTTP
ini_set('session.use_only_cookies', 1);    // Cookies tylko dla sesji
ini_set('session.cookie_secure', 1);        // Tylko HTTPS (production)
ini_set('session.cookie_samesite', 'Strict'); // SameSite policy
```

### 4. Logowanie i monitoring

- **Login Logs**: Rejestracja wszystkich logowań
- **Audit Logs**: Rejestracja ważnych operacji
- **Error Logs**: Logowanie błędów aplikacji

```php
// Logi logowania
INSERT INTO login_logs (user_id, ip_address, user_agent, success)
VALUES (...);

// Logi audytowe
INSERT INTO audit_logs (user_id, action, resource, resource_id, changes)
VALUES (...);
```

### 5. Walidacja danych

- Klasa `Validator` do walidacji formularzy
- Walidacja po stronie serwera (zawsze!)

```php
$validator = new Validator($_POST);
$validator->required('email')
          ->email('email')
          ->minLength('password', PASSWORD_MIN_LENGTH);

if ($validator->fails()) {
    $errors = $validator->getErrors();
}
```

### 6. Uprawnień i dostęp

- Sprawdzanie uprawnień na każdym endpoincie
- RBAC kontroluje dostęp do funkcjonalności

```php
$rbac = new RBAC();
$rbac->requirePermission('users', 'delete');
```

## Raportowanie luk bezpieczeństwa

### Nie otwieraj publicznych issues!

Jeśli odkryjesz lukę bezpieczeństwa:

1. **NIE** publikuj detali w publicznych issues
2. Prześlij email na: `security@firmakot.pl`
3. Opisz lukę szczegółowo
4. Pozwól nam na naprawę (minimum 48 godzin)
5. Następnie możemy opublikować poprawę wspólnie

## Wdrażanie w produkcji

### Wymagane kroki bezpieczeństwa

1. **HTTPS obowiązkowe**
   ```php
   define('BASE_URL', 'https://panel.firmakot.pl');
   // Wtedy session cookies będą secure
   ```

2. **Zmień hasła testowe**
   - admin/password123 → zmień na silne hasło
   - Wszystkie testowe konta usunięcie lub zmiana hasła

3. **Ustaw APP_ENV na production**
   ```
   APP_ENV=production
   ```
   - Wyłącza wyświetlanie błędów
   - Włącza logowanie błędów do pliku

4. **Ustaw silne hasło dla DB**
   ```
   DB_PASSWORD=very_strong_random_password_with_64_chars
   ```

5. **Skonfiguruj OAuth** (opcjonalnie)
   - Discord/Roblox dla logowania

6. **Backup bazy danych**
   ```bash
   pg_dump -U panel_user -d panel_firmakot > backup.sql
   ```

7. **Monitoruj logi**
   ```bash
   tail -f logs/error.log
   tail -f logs/access.log
   ```

## Best Practice do pamiętania

| ✓ RÓB | ✗ NIE RÓB |
|------|---------|
| Sprawdzaj uprawnienia zawsze | Ufaj input z użytkownika |
| Używaj prepared statements | Konkatenuj SQL strings |
| Escapuj wyjście HTML | Umieszczaj dane bez filtru |
| Waliduj dane serwera | Polegaj na JS validation |
| Używaj HTTPS | Wysyłaj data po HTTP |
| Hash hasła bcrypt | Przechowuj hasła plaintext |
| Loguj operacje krytyczne | Ignoruj security events |
| Regeneruj session ID | Używaj starego SID |

## Zmiany bezpieczeństwa

Historia zmian bezpieczeństwa w [CHANGELOG.md](CHANGELOG.md) (jeśli istnieje).

## Zasoby

- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [PHP Security](https://www.php.net/manual/en/security.php)
- [PostgreSQL Security](https://www.postgresql.org/docs/current/sql-syntax.html)

## Kontakt

- Security Email: `security@firmakot.pl`
- GitHub Issues: https://github.com/the-realcar/panel/issues
- GitHub Discussions: https://github.com/the-realcar/panel/discussions
