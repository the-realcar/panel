<?php View::partial('layouts/header', ['page_title' => $page_title]); ?>

<div class="page-header">
    <h1>🗂️ Struktura organizacyjna</h1>
    <a href="/admin/positions/index.php" class="btn btn-secondary">← Powrót do listy stanowisk</a>
</div>

<div class="card">
    <div class="card-body">
        <?php if (empty($tree)): ?>
            <p class="text-muted">Brak zdefiniowanych stanowisk lub działów.</p>
        <?php else: ?>
            <div id="org-tree">
                <?php foreach ($tree as $dept): ?>
                    <div class="department">
                        <h3><?php echo e($dept['department_name'] ?: 'Brak wydziału'); ?></h3>
                        <ul class="position-list">
                            <?php foreach ($dept['positions'] as $pos): ?>
                                <?php
                                    $max = $pos['max_count'];
                                    $cur = $pos['current_count'];
                                    $ratio = ($max === null) ? null : ($max > 0 ? ($cur / $max) : 1);
                                    $badge_class = 'badge-success';
                                    if ($ratio !== null) {
                                        if ($ratio >= 1) $badge_class = 'badge-danger';
                                        elseif ($ratio >= 0.8) $badge_class = 'badge-warning';
                                    }
                                ?>
                                <li>
                                    <div class="pos-row">
                                        <div class="pos-name"><?php echo e($pos['name']); ?></div>
                                        <div class="pos-meta">
                                            <?php if ($max === null): ?>
                                                <span class="badge badge-info"><?php echo e($cur); ?> / ∞</span>
                                            <?php else: ?>
                                                <span class="badge <?php echo $badge_class; ?>"><?php echo e($cur); ?> / <?php echo e($max); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
    #org-tree .department { margin-bottom: 1.5rem; }
    .position-list { list-style: none; padding: 0; margin: 0; }
    .position-list li { padding: 0.5rem 0; border-bottom: 1px solid #f0f0f0; }
    .pos-row { display:flex; justify-content:space-between; align-items:center; }
    .pos-name { font-weight:500; }
    .badge { padding: .25rem .5rem; border-radius: .25rem; }
    .badge-success { background:#d4edda; color:#155724; }
    .badge-warning { background:#fff3cd; color:#856404; }
    .badge-danger { background:#f8d7da; color:#721c24; }
    .badge-info { background:#d1ecf1; color:#0c5460; }
</style>

<?php View::partial('layouts/footer'); ?>
