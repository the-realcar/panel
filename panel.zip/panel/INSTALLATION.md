# Instalacja - Panel Pracowniczy Firma KOT

## Wymagania systemowe

- **PHP**: 8.0 lub wyższy
- **PostgreSQL**: 14 lub wyższy
- **Composer**: (opcjonalnie, ale zalecane)
- **Git**: Do klonowania repozytorium

## Szybki start (Linux/macOS)

### 1. Klonuj repozytorium

```bash
git clone https://github.com/the-realcar/panel.git
cd panel
```

### 2. Konfiguracja bazy danych

#### Zaloguj się do PostgreSQL

```bash
sudo -u postgres psql
```

#### Utwórz bazę danych i użytkownika

```sql
CREATE DATABASE panel_firmakot;
CREATE USER panel_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE panel_firmakot TO panel_user;
\q
```

#### Zaimportuj schemat

```bash
psql -U panel_user -d panel_firmakot -f database/schema.sql
```

#### Załaduj dane testowe (opcjonalnie)

```bash
psql -U panel_user -d panel_firmakot -f database/seeds.sql
```

### 3. Konfiguracja zmiennych środowiskowych

Skopiuj plik `.env.example` do `.env`:

```bash
cp .env.example .env
```

Edytuj `.env` i ustaw wartości:

```bash
nano .env
```

### 4. Uruchom serwer PHP

```bash
php -S localhost:8000
```

Aplikacja będzie dostępna na: `http://localhost:8000`

## Szybki start (Windows)

### 1. Przygotowanie PostgreSQL

Zainstaluj PostgreSQL z: https://www.postgresql.org/download/windows/

Podczas instalacji pamiętaj hasło superusera (`postgres`).

### 2. Utwórz bazę danych

Otwórz PowerShell i wykonaj:

```powershell
psql -U postgres
```

Wpisz hasło i wykonaj SQL:

```sql
CREATE DATABASE panel_firmakot;
CREATE USER panel_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE panel_firmakot TO panel_user;
\q
```

### 3. Zaimportuj schemat

```powershell
psql -U panel_user -d panel_firmakot -f database/schema.sql
```

### 4. Konfiguracja zmiennych środowiskowych

Skopiuj `.env.example` do `.env`:

```powershell
Copy-Item .env.example .env
```

Edytuj `.env` i ustaw wartości.

### 5. Uruchom serwer PHP

```powershell
php -S 127.0.0.1:8000
```

## Dane logowania testowe

Po załadowaniu `seeds.sql` dostępne są następujące konta:

| Użytkownik | Hasło | Rola |
|------------|-------|------|
| `admin` | `password123` | Administrator |
| `kierowca1` | `password123` | Kierowca |
| `dyspozytor1` | `password123` | Dyspozytor |

**⚠️ WAŻNE**: Zmień te hasła w produkcji!

## Zarządzanie użytkownikami z CLI

### Utwórz nowego użytkownika

```bash
php cli.php user:create
```

Następnie odpowiedz na pytania: username, email, hasło.

### Wyświetl listę użytkowników

```bash
php cli.php user:list
```

### Resetuj hasło użytkownika

```bash
php cli.php user:reset-password admin
```

## Konfiguracja OAuth (opcjonalnie)

### Discord OAuth

1. Przejdź do: https://discord.com/developers/applications
2. Utwórz nową aplikację
3. W sekcji OAuth2 > Redirects dodaj:
   - `http://localhost:8000/oauth/discord-callback.php`
4. Skopiuj Client ID i Client Secret do `.env`:

```bash
DISCORD_CLIENT_ID=xxx
DISCORD_CLIENT_SECRET=yyy
```

### Roblox OAuth

1. Przejdź do: https://www.roblox.com/develop
2. Konfiguruj OAuth aplikację
3. Skopiuj dane do `.env`:

```bash
ROBLOX_CLIENT_ID=xxx
ROBLOX_CLIENT_SECRET=yyy
```

## API Documentation

Pełną dokumentację API znaleźć można w pliku [API.md](API.md).

**Przykład użycia API:**

```bash
# Zaloguj się
curl -c cookies.txt -X POST http://localhost:8000/login.php \
  -d "username=admin&password=password123"

# Pobierz listę użytkowników
curl -b cookies.txt http://localhost:8000/public/api/users.php?page=1&limit=20
```

## Rozwiązywanie problemów

### Błąd połączenia z bazą danych

**Symptom:**
```
PDO Exception: could not find driver
```

**Rozwiązanie:**
Zainstaluj rozszerzenie PostgreSQL dla PHP:

```bash
# Ubuntu/Debian
sudo apt-get install php-pgsql

# macOS (z Homebrew)
brew install php@8.1 php@8.1-pgsql

# Windows
Odkomentuj w php.ini: `extension=pdo_pgsql`
```

### Błędy uprawnień

**Symptom:**
```
SQLSTATE[08006] connection refused
```

**Rozwiązanie:**
Sprawdź czy PostgreSQL jest uruchomiony:

```bash
# Linux
sudo systemctl status postgresql

# macOS
brew services list

# Windows
services.msc (sprawdź PostgreSQL)
```

### Session nie działa

**Symptom:**
```
Session directory is not writable
```

**Rozwiązanie:**
Utwórz katalog sessions:

```bash
mkdir -p sessions
chmod 777 sessions
```

### Dark Mode się nie załadowuje

**Rozwiązanie:**
Sprawdź w DevTools czy `dark-mode.js` jest załadowany (Network tab).
Wyczyść cache przeglądarki (Ctrl+Shift+Delete).

## Dalszy development

### Struktura projektu

```
panel/
├── admin/              # Widoki panelu admin (legacy)
├── app/
│   ├── Controllers/    # Kontrolery
│   ├── Models/         # Modele bazy danych
│   ├── Views/          # Szablony widoków
│   └── Core/           # Klasy bazowe
├── config/             # Konfiguracja (database, session, config)
├── core/               # Klasy core (Auth, RBAC, Database, Validator)
├── database/           # Skrypty SQL
├── includes/           # Funkcje pomocnicze
├── public/
│   ├── api/            # REST API endpointy
│   ├── assets/         # CSS, JS, obrazki
│   ├── driver/         # Panel kierowcy (legacy)
│   └── (pozostałe widoki)
└── cli.php             # Command Line Interface

```

### Dodawanie nowych kontrolerów

Utwórz plik: `app/Controllers/YourController.php`

```php
<?php

class YourController {
    private $db;
    
    public function __construct() {
        $this->db = new Database();
    }
    
    public function index() {
        // Your logic
    }
}
```

### Routing

Projekt nie ma wbudowanego routera. Routing odbywa się poprzez bezpośrednie odwołania do plików PHP lub przez include w głównym `index.php`.

## Wsparcie

W razie pytań lub problemów:
- Sprawdź [README.md](README.md)
- Sprawdź [API.md](API.md)
- Otwórz issue na GitHub: https://github.com/the-realcar/panel/issues
