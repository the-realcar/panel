# CONTRIBUTING - Wkład w projekt

## Wytyczne dla deweloperów

Dziękujemy za zainteresowanie projektem! Poniżej znajduje się kilka wytycznych dla osób chcących wnieść wkład w development.

## Kod style

### PHP

- **Indent**: 4 spacje (bez tabów)
- **Naming**: camelCase dla funkcji/metod, snake_case dla zmiennych
- **Brackets**: Opening bracket na końcu linii (PSR-12)

```php
<?php

class MyClass {
    public function myMethod() {
        if ($condition) {
            // code
        }
    }
}
```

### HTML/CSS

- **Indent**: 2 spacje
- **Accessibility**: Zawsze używaj semantycznych tagów HTML
- **Classes**: kebab-case (`.my-class`)

### JavaScript

- **Indent**: 4 spacje
- **Naming**: camelCase
- **Strict mode**: Zawsze na górze pliku

## Proces zgłaszania pull requestów

### 1. Fork repozytorium

```bash
git clone https://github.com/[YOUR_USERNAME]/panel.git
cd panel
```

### 2. Utwórz branch

```bash
git checkout -b feature/your-feature-name
```

### 3. Commit z wiadomościami

Wiadomości commitów powinny być descriptive:

```bash
git commit -m "Add API endpoint for schedules"
git commit -m "Fix CSRF validation in user controller"
```

### 4. Push do forka

```bash
git push origin feature/your-feature-name
```

### 5. Otwórz Pull Request

Na GitHub otwórz PR z opisem zmian.

## Format Pull Requestu

```markdown
## Opis
Krótki opis co zmienia ten PR.

## Typ zmian
- [ ] Bug fix
- [ ] Nowa funkcjonalność
- [ ] Zmiana dokumentacji
- [ ] Refactoring

## Jak testować
Instrukcje do potwierdzenia zmian.

## Checklist
- [ ] Kod następuje wytyczne projektu
- [ ] Dodane są komentarze w kodzie
- [ ] Zaktualizowana dokumentacja
- [ ] Wersja PHP ≥ 8.0
```

## Struktura kodu

### Kontrolery

Umieścić w: `app/Controllers/YourController.php`

```php
<?php

class YourController {
    private $db;
    private $rbac;
    
    public function __construct() {
        $this->db = new Database();
        $this->rbac = new RBAC();
    }
    
    public function index() {
        requireLogin();
        $this->rbac->requirePermission('resource', 'read');
        
        // Your logic
    }
}
```

### Modele

Umieścić w: `app/Models/YourModel.php`

```php
<?php

class YourModel {
    public static function findAll() {
        $db = new Database();
        return $db->query("SELECT * FROM your_table");
    }
    
    public static function create(array $data) {
        $db = new Database();
        return $db->execute("INSERT INTO your_table ...", $data);
    }
}
```

### API Endpoints

Umieścić w: `public/api/your-resource.php`

```php
<?php

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../core/Auth.php';
require_once __DIR__ . '/../../core/RBAC.php';

header('Content-Type: application/json; charset=utf-8');

// Validate authentication
if (!isLoggedIn() || !checkSessionTimeout()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Check permissions
$rbac = new RBAC();
if (!$rbac->hasPermission('resource', 'read')) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

try {
    // Your logic
    http_response_code(200);
    echo json_encode(['success' => true, 'data' => $data]);
} catch (Exception $e) {
    error_log('API Error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Internal server error']);
}
```

## Bezpieczeństwo

### Porady

1. **SQL Injection**: Zawsze używaj prepared statements z PDO:
   ```php
   $db->execute("SELECT * FROM users WHERE id = :id", [':id' => $id]);
   ```

2. **XSS**: Escapuj wyjście HTML:
   ```php
   echo e($user_input); // function e() w includes/functions.php
   ```

3. **CSRF**: Sprawdzaj tokeny w POST:
   ```php
   if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
       die('Invalid CSRF token');
   }
   ```

4. **Autoryzacja**: Zawsze sprawdzaj uprawnienia:
   ```php
   $rbac->requirePermission('resource', 'action');
   ```

5. **Walidacja**: Waliduj dane wejściowe:
   ```php
   $validator = new Validator($_POST);
   $validator->required('email')->email('email');
   if ($validator->fails()) {
       // Handle errors
   }
   ```

## Testing

### PHP Linting

```bash
find . -name "*.php" -type f | xargs php -l
```

### Manualne testowanie

1. Przeprowadź operacje w interfejsie (CRUD)
2. Sprawdź API endpointy z curl lub Postman
3. Zaloguj się na różnych rolach (admin, driver, dispatcher)

## Dokumentacja

- Aktualizuj [README.md](README.md) dla zmian w funkcjonalności
- Aktualizuj [API.md](API.md) dla nowych API endpointów
- Aktualizuj [INSTALLATION.md](INSTALLATION.md) dla zmian w setup

## Komunikacja

- Otwarte PR i issues na GitHub
- Odpowiadaj na pytania w Issues
- Opisuj problem / rozwiązanie jasno

## Licencja

Tech projekt jest własnością Firmy KOT. Wszystkie prawa zastrzeżone.
