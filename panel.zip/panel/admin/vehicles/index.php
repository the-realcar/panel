<?php

require_once __DIR__ . '/../../app/bootstrap.php';

$controller = new AdminVehiclesController();
$controller->index();
