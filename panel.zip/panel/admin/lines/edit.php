<?php

require_once __DIR__ . '/../../app/bootstrap.php';

$controller = new AdminLinesController();
$controller->edit();
