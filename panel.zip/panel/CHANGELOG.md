# CHANGELOG - Historia zmian

Wszystkie zawarte zmiany w tym projekcie będą dokumentowane w tym pliku.

Format opiera się na [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [Unreleased]

### Dodane
- API REST endpointy dla zasobów:
  - `/api/users.php` - Użytkownicy
  - `/api/vehicles.php` - Pojazdy
  - `/api/lines.php` - Linie komunikacyjne
  - `/api/stops.php` - Przystanki
  - `/api/platforms.php` - Platformy
  - `/api/brigades.php` - Brygady
  - `/api/positions.php` - Stanowiska z licznikami limitów
  - `/api/schedules.php` - Grafiki pracy
  - `/api/incidents.php` - Incydenty/awarie (GET i POST)
  - `/api/dashboard-stats.php` - Statystyki panelu
- CLI interface (`cli.php`):
  - `user:create` - Tworzenie użytkownika
  - `user:list` - Lista użytkowników
  - `user:reset-password` - Reset hasła
  - `db:seed` - Załadowanie danych testowych
- Dokumentacja:
  - [API.md](API.md) - Pełna dokumentacja API
  - [INSTALLATION.md](INSTALLATION.md) - Instrukcje instalacji
  - [CONTRIBUTING.md](CONTRIBUTING.md) - Wytyczne dla developerów
  - [SECURITY.md](SECURITY.md) - Polityka bezpieczeństwa
- [.env.example](.env.example) - Plik template zmiennych środowiskowych
- Poprawiona walidacja uprawnień w API

### Zmienione
- Wszystkie API endpointy implementują RBAC
- API statystyk dostosowane do roli użytkownika

### Planowane (TODO)
- POST/PUT/DELETE endpointy do API
- Wsparcie dla paginacji na wszystkich endpointach
- Dokumentacja Swagger/OpenAPI
- Testy jednostkowe
- Integracja z CI/CD (GitHub Actions)

---

## [1.0.0] - 2026-01-15

Pierwsza stabilna wersja Panel Pracowniczy Firma KOT.

### Dodane w v1.0.0
- System logowania i autoryzacji
- RBAC (Role-Based Access Control)
- Dark Mode
- Panel administracyjny:
  - Zarządzanie użytkownikami i rolami
  - CRUD - Pojazdy
  - CRUD - Linie komunikacyjne
  - CRUD - Stanowiska z limitami
  - Dashboard z statystykami
- Panel kierowcy:
  - Grafiki pracy
  - Karty drogowe
  - Zgłaszanie incydentów
- Panel dyspozytora:
  - Zarządzanie grafikami
  - Przegląd floty
- OAuth integracji (Discord, Roblox)
- REST API podstawowe
- Responsywny design (mobile-first)
- Logi logowania i audytowe
- Ochrona CSRF
- Session managementem
- Walidacja formularzy

---

## Konwencje

### Versioning

Projekt następuje [Semantic Versioning](https://semver.org/):
- **MAJOR** - Zmiany nie-kompatybilne
- **MINOR** - Nowa funkcjonalność (kompatybilna)
- **PATCH** - Poprawki błędów

### Tagi

- `added` - Nowa funkcjonalność
- `changed` - Zmiana w istniejącym
- `deprecated` - Wkrótce do usunięcia
- `removed` - Usunięte funkcje
- `fixed` - Poprawki błędów
- `security` - Poprawki bezpieczeństwa

### Format commit message

```
[KATEGORIA] Krótki opis
[feat] Add API endpoint for users
[fix] Fix CSRF validation error
[docs] Add API documentation
[chore] Update dependencies
```

---

Ostatnia aktualizacja: 2026-03-04
