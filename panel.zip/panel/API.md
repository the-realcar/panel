# API Documentation - Panel Pracowniczy Firma KOT

## Ogólne informacje

Wszystkie endpointy API wymagają:
- Zalogowania (autoryzacji)
- Sesji aktywnej
- Odpowiednich uprawnień

Wszystkie odpowiedzi zwracane są w formacie JSON.

## Błędy HTTP

- `200` - OK
- `400` - Bad Request
- `401` - Unauthorized (brak logowania)
- `403` - Forbidden (brak uprawnień)
- `404` - Not Found
- `500` - Internal Server Error

## Endpointy

### Users - Użytkownicy

#### GET `/api/users.php`

Pobiera listę użytkowników.

**Query Parameters:**
- `page` (int, default: 1) - Numer strony
- `limit` (int, default: 20, max: 100) - Ilość elementów na stronę
- `status` (string) - Filtr: `active`, `inactive` lub puste

**Wymagane uprawnienia:** `users.read`

**Przykład:**
```bash
curl -b cookies.txt http://localhost/api/users.php?page=1&limit=20&status=active
```

**Odpowiedź:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "username": "admin",
      "email": "admin@firmakot.pl",
      "first_name": "Admin",
      "last_name": "System",
      "active": true,
      "roles": "Administrator",
      "positions": "Główny Administrator",
      "created_at": "2026-01-15T10:30:00Z",
      "updated_at": "2026-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "pages": 8
  }
}
```

---

### Vehicles - Pojazdy

#### GET `/api/vehicles.php`

Pobiera listę pojazdów.

**Query Parameters:**
- `page` (int, default: 1) - Numer strony
- `limit` (int, default: 20, max: 100) - Ilość elementów na stronę

**Wymagane uprawnienia:** `vehicles.read`

**Przykład:**
```bash
curl -b cookies.txt http://localhost/api/vehicles.php?page=1&limit=50
```

**Odpowiedź:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "registration_number": "KR-12345",
      "type": "bus",
      "model": "MAN Lion's City",
      "seating_capacity": 55,
      "created_at": "2026-01-15T10:30:00Z",
      "updated_at": "2026-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 50,
    "total": 250,
    "pages": 5
  }
}
```

---

### Lines - Linie

#### GET `/api/lines.php`

Pobiera listę linii komunikacyjnych.

**Query Parameters:**
- `page` (int, default: 1) - Numer strony
- `limit` (int, default: 20, max: 100) - Ilość elementów na stronę

**Wymagane uprawnienia:** `lines.read`

**Przykład:**
```bash
curl -b cookies.txt http://localhost/api/lines.php?page=1
```

**Odpowiedź:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "line_number": "1",
      "name": "Linia 1: Centrum - Dworzec",
      "description": "Linia komunikacyjna",
      "created_at": "2026-01-15T10:30:00Z",
      "updated_at": "2026-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 45,
    "pages": 3
  }
}
```

---

### Stops - Stacje

#### GET `/api/stops.php`

Pobiera listę przystanków.

**Query Parameters:**
- `page` (int, default: 1) - Numer strony
- `limit` (int, default: 20, max: 100) - Ilość elementów na stronę

**Wymagane uprawnienia:** `stops.read`

**Przykład:**
```bash
curl -b cookies.txt http://localhost/api/stops.php?page=1
```

**Odpowiedź:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "name": "Dworzec Główny",
      "code": "DW-01",
      "city": "Kraków",
      "latitude": "50.0456",
      "longitude": "19.9446",
      "created_at": "2026-01-15T10:30:00Z",
      "updated_at": "2026-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 320,
    "pages": 16
  }
}
```

---

### Platforms - Platformy

#### GET `/api/platforms.php`

Pobiera listę platform.

**Query Parameters:**
- `page` (int, default: 1) - Numer strony
- `limit` (int, default: 20, max: 100) - Ilość elementów na stronę

**Wymagane uprawnienia:** `platforms.read`

**Przykład:**
```bash
curl -b cookies.txt http://localhost/api/platforms.php?page=1
```

**Odpowiedź:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "name": "Platforma A",
      "code": "PLA",
      "description": "Platforma dla linii 1-5",
      "created_at": "2026-01-15T10:30:00Z",
      "updated_at": "2026-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 8,
    "pages": 1
  }
}
```

---

## Autentykacja

Wszystkie żądania API wymagają aktywnej sesji. Można zalogować się przez:

1. **Formularz logowania** (`/login.php`)
2. **OAuth** (Discord/Roblox)

Po zalogowaniu cookie sesji jest automatycznie ustawiany.

**Używanie curl z cookies:**
```bash
# Logowanie
curl -c cookies.txt -X POST http://localhost/login.php \
  -d "username=admin&password=password123&csrf_token=TOKEN"

# Użycie API
curl -b cookies.txt http://localhost/api/users.php
```

---

## Best Practices

1. **Paginacja** - Zawsze używaj paginacji dla dużych zbiorów danych
2. **Limit** - Nie przesyłaj więcej niż 100 elementów na raz
3. **Caching** - Odpowiedzi API zwracają timestamp, możesz cachować lokalne dane
4. **Error Handling** - Zawsze sprawdzaj status HTTP i pole `success` w odpowiedzi

---

---

### Brigades - Brygady

#### GET `/api/brigades.php`

Pobiera listę brygad.

**Query Parameters:**
- `page` (int, default: 1)
- `limit` (int, default: 20, max: 100)

**Wymagane uprawnienia:** `brigades.read`

---

### Positions - Stanowiska

#### GET `/api/positions.php`

Pobiera listę stanowisk z informacją o limitach i dostępnych miejscach.

**Query Parameters:**
- `page` (int, default: 1)
- `limit` (int, default: 20, max: 100)

**Wymagane uprawnienia:** `positions.read`

**Response zawiera:**
- `position_limit` - Maksymalny limit osób
- `current_count` - Obecna liczba osób
- `available` - Dostępne miejsca

---

### Schedules - Grafiki

#### GET `/api/schedules.php`

Pobiera grafiki pracy. Kierowcy widzą tylko swoje, admini widzą wszystkie.

**Query Parameters:**
- `date_from` (string, format: YYYY-MM-DD, default: dzisiaj)
- `date_to` (string, format: YYYY-MM-DD, default: +7 dni)
- `user_id` (int, tylko admin)

**Wymagane uprawnienia:** `schedules.read`

---

### Incidents - Incydenty/Awarie

#### GET `/api/incidents.php`

Pobiera listę incydentów/awarii.

**Query Parameters:**
- `page` (int, default: 1)
- `limit` (int, default: 20, max: 100)
- `status` (string) - Filtr: `open`, `resolved`, `closed`
- `severity` (string) - Filtr: `low`, `medium`, `high`, `critical`
- `user_id` (int, tylko admin)

**Wymagane uprawnienia:** `incidents.read`

#### POST `/api/incidents.php`

Tworzy nowy incydent (akcja kierowcy).

**Request Body (JSON):**
```json
{
  "title": "Uszkodzenie szyby",
  "description": "Rozbita szyba holu głównego",
  "severity": "high",
  "vehicle_id": 5
}
```

**Wymagane uprawnienia:** `incidents.create`

---

### Dashboard Stats - Statystyki

#### GET `/api/dashboard-stats.php`

Pobiera statystyki panelu dostosowane do roli użytkownika.

**Admin otrzymuje:**
```json
{
  "users": { "total": 150, "active": 148 },
  "vehicles": { "total": 250 },
  "lines": { "total": 45 },
  "incidents": { "today": 3, "open": 5 }
}
```

**Kierowca/Dyspozytor otrzymuje:**
```json
{
  "schedules": { "today": 1 },
  "incidents": { "today": 0, "open": 1 }
}
```

**Wymagane uprawnienia:** Zalogowanie

---

## Przyszłe endpointy

Planowane do implementacji:
- `POST /api/users.php` - Tworzenie użytkownika
- `PUT /api/users/{id}.php` - Edycja użytkownika
- `DELETE /api/users/{id}.php` - Usuwanie użytkownika
- `GET /api/route-cards.php` - Karty drogowe
- `POST /api/route-cards.php` - Tworzenie karty drogowej
- `PUT /api/incidents/{id}.php` - Aktualizacja incydentu
