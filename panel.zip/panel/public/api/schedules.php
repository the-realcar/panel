<?php
/**
 * Schedules API Endpoint
 * Panel Pracowniczy Firma KOT
 */

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../core/Auth.php';
require_once __DIR__ . '/../../core/RBAC.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn() || !checkSessionTimeout()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$rbac = new RBAC();
if (!$rbac->hasPermission('schedules', 'read')) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

try {
    $db = new Database();
    $user_id = getCurrentUserId();
    
    // Filter options
    $date_from = $_GET['date_from'] ?? date('Y-m-d');
    $date_to = $_GET['date_to'] ?? date('Y-m-d', strtotime('+7 days'));
    $user_filter = $_GET['user_id'] ?? null;
    
    // Admin can filter by user, drivers see only their own
    if (!$rbac->isAdmin() && $user_filter && $user_filter != $user_id) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden']);
        exit;
    }
    
    // Build query
    $where = "WHERE s.schedule_date BETWEEN :date_from AND :date_to";
    $params = [':date_from' => $date_from, ':date_to' => $date_to];
    
    if ($user_filter) {
        $where .= " AND s.user_id = :user_id";
        $params[':user_id'] = $user_filter;
    } elseif (!$rbac->isAdmin()) {
        $where .= " AND s.user_id = :user_id";
        $params[':user_id'] = $user_id;
    }
    
    $schedules = $db->query(
        "SELECT s.*, u.first_name, u.last_name, u.username, 
                l.line_number, l.name as line_name,
                v.registration_number as vehicle_reg
         FROM schedules s
         LEFT JOIN users u ON s.user_id = u.id
         LEFT JOIN lines l ON s.line_id = l.id
         LEFT JOIN vehicles v ON s.vehicle_id = v.id
         $where
         ORDER BY s.schedule_date ASC, s.start_time ASC",
        $params
    );

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'data' => $schedules,
        'filters' => [
            'date_from' => $date_from,
            'date_to' => $date_to,
            'user_id' => $user_filter
        ]
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} catch (Exception $e) {
    error_log('API Error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Internal server error']);
}
