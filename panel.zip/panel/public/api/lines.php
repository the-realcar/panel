<?php
/**
 * Lines API Endpoint
 * Panel Pracowniczy Firma KOT
 */

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../core/Auth.php';
require_once __DIR__ . '/../../core/RBAC.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn() || !checkSessionTimeout()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$rbac = new RBAC();
if (!$rbac->hasPermission('lines', 'read')) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

try {
    $page = (int)($_GET['page'] ?? 1);
    $page = max(1, $page);
    $limit = (int)($_GET['limit'] ?? ITEMS_PER_PAGE);
    $limit = min($limit, 100);
    $offset = ($page - 1) * $limit;

    $db = new Database();
    
    $count_result = $db->queryOne("SELECT COUNT(*) as total FROM lines");
    $total = (int)($count_result['total'] ?? 0);

    $lines = $db->query(
        "SELECT * FROM lines ORDER BY line_number ASC LIMIT :limit OFFSET :offset",
        [':limit' => $limit, ':offset' => $offset]
    );

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'data' => $lines,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pages' => (int)ceil($total / $limit)
        ]
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} catch (Exception $e) {
    error_log('API Error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Internal server error']);
}
