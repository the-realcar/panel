<?php
/**
 * Incidents API Endpoint
 * Panel Pracowniczy Firma KOT
 */

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../core/Auth.php';
require_once __DIR__ . '/../../core/RBAC.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn() || !checkSessionTimeout()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$rbac = new RBAC();

// Check if method is POST for creating incident (driver)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$rbac->hasPermission('incidents', 'create')) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden']);
        exit;
    }
    
    // Create incident
    try {
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Validate required fields
        if (empty($data['title']) || empty($data['description'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Title and description are required']);
            exit;
        }
        
        $db = new Database();
        $user_id = getCurrentUserId();
        
        $db->execute(
            "INSERT INTO incidents (user_id, vehicle_id, title, description, severity, status, created_at)
             VALUES (:user_id, :vehicle_id, :title, :description, :severity, 'open', CURRENT_TIMESTAMP)",
            [
                ':user_id' => $user_id,
                ':vehicle_id' => $data['vehicle_id'] ?? null,
                ':title' => $data['title'],
                ':description' => $data['description'],
                ':severity' => $data['severity'] ?? 'medium'
            ]
        );
        
        http_response_code(201);
        echo json_encode(['success' => true, 'message' => 'Incident created']);
    } catch (Exception $e) {
        error_log('API Error: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Internal server error']);
    }
    exit;
}

// GET incidents
if (!$rbac->hasPermission('incidents', 'read')) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

try {
    $db = new Database();
    $user_id = getCurrentUserId();
    
    $page = (int)($_GET['page'] ?? 1);
    $page = max(1, $page);
    $limit = (int)($_GET['limit'] ?? ITEMS_PER_PAGE);
    $limit = min($limit, 100);
    $offset = ($page - 1) * $limit;
    
    // Filter options
    $status = $_GET['status'] ?? null;
    $severity = $_GET['severity'] ?? null;
    $user_filter = $_GET['user_id'] ?? null;
    
    // Build query
    $where = "WHERE 1=1";
    $params = [];
    
    // Admin sees all, drivers see only theirs
    if (!$rbac->isAdmin()) {
        $where .= " AND i.user_id = :user_id";
        $params[':user_id'] = $user_id;
    } elseif ($user_filter) {
        $where .= " AND i.user_id = :user_id";
        $params[':user_id'] = $user_filter;
    }
    
    if ($status) {
        $where .= " AND i.status = :status";
        $params[':status'] = $status;
    }
    
    if ($severity) {
        $where .= " AND i.severity = :severity";
        $params[':severity'] = $severity;
    }
    
    // Count total
    $count_result = $db->queryOne("SELECT COUNT(*) as total FROM incidents i $where", $params);
    $total = (int)($count_result['total'] ?? 0);
    
    // Get incidents
    $incidents = $db->query(
        "SELECT i.*, u.first_name, u.last_name, u.username, v.registration_number
         FROM incidents i
         LEFT JOIN users u ON i.user_id = u.id
         LEFT JOIN vehicles v ON i.vehicle_id = v.id
         $where
         ORDER BY i.created_at DESC
         LIMIT :limit OFFSET :offset",
        array_merge($params, [':limit' => $limit, ':offset' => $offset])
    );

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'data' => $incidents,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pages' => (int)ceil($total / $limit)
        ]
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} catch (Exception $e) {
    error_log('API Error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Internal server error']);
}
