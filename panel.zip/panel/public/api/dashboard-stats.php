<?php
/**
 * Dashboard Stats API Endpoint
 * Panel Pracowniczy Firma KOT
 */

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../core/Auth.php';
require_once __DIR__ . '/../../core/RBAC.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn() || !checkSessionTimeout()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

try {
    $db = new Database();
    $rbac = new RBAC();
    $user_id = getCurrentUserId();
    
    // Admin stats
    if ($rbac->isAdmin()) {
        $users_count = $db->queryOne("SELECT COUNT(*) as count FROM users")['count'];
        $active_users = $db->queryOne("SELECT COUNT(*) as count FROM users WHERE active = TRUE")['count'];
        $vehicles_count = $db->queryOne("SELECT COUNT(*) as count FROM vehicles")['count'];
        $lines_count = $db->queryOne("SELECT COUNT(*) as count FROM lines")['count'];
        $incidents_today = $db->queryOne(
            "SELECT COUNT(*) as count FROM incidents WHERE DATE(created_at) = CURRENT_DATE"
        )['count'];
        $incidents_open = $db->queryOne(
            "SELECT COUNT(*) as count FROM incidents WHERE status = 'open'"
        )['count'];
        
        $data = [
            'users' => [
                'total' => (int)$users_count,
                'active' => (int)$active_users
            ],
            'vehicles' => [
                'total' => (int)$vehicles_count
            ],
            'lines' => [
                'total' => (int)$lines_count
            ],
            'incidents' => [
                'today' => (int)$incidents_today,
                'open' => (int)$incidents_open
            ]
        ];
    } else {
        // Driver/dispatcher stats
        $today_schedules = $db->queryOne(
            "SELECT COUNT(*) as count FROM schedules WHERE user_id = :user_id AND DATE(schedule_date) = CURRENT_DATE",
            [':user_id' => $user_id]
        )['count'];
        
        $incidents_today = $db->queryOne(
            "SELECT COUNT(*) as count FROM incidents WHERE user_id = :user_id AND DATE(created_at) = CURRENT_DATE",
            [':user_id' => $user_id]
        )['count'];
        
        $incidents_open = $db->queryOne(
            "SELECT COUNT(*) as count FROM incidents WHERE user_id = :user_id AND status = 'open'",
            [':user_id' => $user_id]
        )['count'];
        
        $data = [
            'schedules' => [
                'today' => (int)$today_schedules
            ],
            'incidents' => [
                'today' => (int)$incidents_today,
                'open' => (int)$incidents_open
            ]
        ];
    }

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'data' => $data
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} catch (Exception $e) {
    error_log('API Error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Internal server error']);
}
