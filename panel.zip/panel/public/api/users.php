<?php
/**
 * Users API Endpoint
 * Panel Pracowniczy Firma KOT
 * 
 * Returns list of users in JSON format
 * Requires authentication and 'users' read permission
 */

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../core/Auth.php';
require_once __DIR__ . '/../../core/RBAC.php';

// Set JSON response header
header('Content-Type: application/json; charset=utf-8');

// Check if user is logged in
if (!isLoggedIn() || !checkSessionTimeout()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Check permissions
$rbac = new RBAC();
if (!$rbac->hasPermission('users', 'read')) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

try {
    // Get query parameters
    $status_filter = $_GET['status'] ?? '';
    $page = (int)($_GET['page'] ?? 1);
    $page = max(1, $page);
    $limit = (int)($_GET['limit'] ?? ITEMS_PER_PAGE);
    $limit = min($limit, 100); // Max 100 items per page
    $offset = ($page - 1) * $limit;

    // Count total users
    $total = User::countByStatus($status_filter);

    // Get users with roles and positions
    $users = User::listWithRolesPositions($status_filter, $limit, $offset);

    // Format response
    $response = [
        'success' => true,
        'data' => $users,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pages' => (int)ceil($total / $limit)
        ]
    ];

    http_response_code(200);
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} catch (Exception $e) {
    error_log('API Error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'error' => 'Internal server error',
        'message' => APP_ENV === 'development' ? $e->getMessage() : 'An error occurred'
    ]);
}
