#!/usr/bin/env php
<?php
/**
 * CLI - Command Line Interface
 * Panel Pracowniczy Firma KOT
 */

require_once __DIR__ . '/app/bootstrap.php';

// Simple CLI argument parser
$command = $argv[1] ?? null;
$args = array_slice($argv, 2);

if (!$command) {
    showUsage();
    exit(1);
}

switch ($command) {
    case 'user:create':
        handleUserCreate($args);
        break;
    case 'user:list':
        handleUserList($args);
        break;
    case 'user:reset-password':
        handleResetPassword($args);
        break;
    case 'db:seed':
        handleDbSeed($args);
        break;
    case 'help':
        showUsage();
        break;
    default:
        echo "Unknown command: $command\n";
        showUsage();
        exit(1);
}

/**
 * Create new user
 */
function handleUserCreate($args) {
    echo "=== Tworzenie nowego użytkownika ===\n\n";
    
    $username = prompt("Username: ");
    if (!$username) {
        echo "Error: Username is required\n";
        exit(1);
    }
    
    $email = prompt("Email: ");
    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Error: Valid email is required\n";
        exit(1);
    }
    
    $first_name = prompt("First Name: ");
    $last_name = prompt("Last Name: ");
    
    $password = promptPassword("Password: ");
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        echo "Error: Password must be at least " . PASSWORD_MIN_LENGTH . " characters\n";
        exit(1);
    }
    
    $password_confirm = promptPassword("Confirm Password: ");
    if ($password !== $password_confirm) {
        echo "Error: Passwords don't match\n";
        exit(1);
    }
    
    try {
        $db = new Database();
        
        // Check if user exists
        $existing = $db->queryOne(
            "SELECT id FROM users WHERE username = :username OR email = :email",
            [':username' => $username, ':email' => $email]
        );
        
        if ($existing) {
            echo "Error: User with this username or email already exists\n";
            exit(1);
        }
        
        // Create user
        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        $user_id = User::create([
            'username' => $username,
            'email' => $email,
            'password_hash' => $password_hash,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'active' => true,
            'discord_id' => null,
            'roblox_id' => null
        ]);
        
        echo "\n✓ Użytkownik utworzony:\n";
        echo "  ID: $user_id\n";
        echo "  Username: $username\n";
        echo "  Email: $email\n";
        echo "  Nazwa: $first_name $last_name\n\n";
        
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage() . "\n";
        exit(1);
    }
}

/**
 * List users
 */
function handleUserList($args) {
    try {
        $db = new Database();
        $users = $db->query("SELECT id, username, email, first_name, last_name, active FROM users ORDER BY username ASC");
        
        echo "\n=== Lista użytkowników ===\n\n";
        printf("%-4s | %-15s | %-25s | %-15s | %-10s\n", "ID", "Username", "Email", "Nazwa", "Status");
        echo str_repeat("-", 75) . "\n";
        
        foreach ($users as $user) {
            printf(
                "%-4d | %-15s | %-25s | %-15s | %s\n",
                $user['id'],
                substr($user['username'], 0, 15),
                substr($user['email'], 0, 25),
                substr($user['first_name'] . ' ' . $user['last_name'], 0, 15),
                $user['active'] ? 'Aktywny' : 'Nieaktywny'
            );
        }
        echo "\n";
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage() . "\n";
        exit(1);
    }
}

/**
 * Reset password
 */
function handleResetPassword($args) {
    if (empty($args[0])) {
        echo "Usage: php cli.php user:reset-password <username>\n";
        exit(1);
    }
    
    $username = $args[0];
    $new_password = promptPassword("New Password: ");
    
    if (strlen($new_password) < PASSWORD_MIN_LENGTH) {
        echo "Error: Password must be at least " . PASSWORD_MIN_LENGTH . " characters\n";
        exit(1);
    }
    
    try {
        $db = new Database();
        $user = $db->queryOne("SELECT id FROM users WHERE username = :username", [':username' => $username]);
        
        if (!$user) {
            echo "Error: User not found\n";
            exit(1);
        }
        
        $password_hash = password_hash($new_password, PASSWORD_BCRYPT);
        User::updatePassword($user['id'], $password_hash);
        
        echo "✓ Hasło zmienione dla użytkownika: $username\n";
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage() . "\n";
        exit(1);
    }
}

/**
 * Seed database
 */
function handleDbSeed($args) {
    echo "This command would run database seeders\n";
    echo "Not yet implemented\n";
}

/**
 * CLI Prompt helper
 */
function prompt($question) {
    echo $question;
    return trim(fgets(STDIN));
}

/**
 * CLI Password prompt (hidden input)
 */
function promptPassword($question) {
    echo $question;
    system('stty -echo');
    $password = trim(fgets(STDIN));
    system('stty echo');
    echo "\n";
    return $password;
}

/**
 * Show usage information
 */
function showUsage() {
    echo <<<USAGE
Panel Pracowniczy Firma KOT - CLI

Usage:
  php cli.php <command> [arguments]

Commands:
  user:create              Utwórz nowego użytkownika
  user:list               Wyświetl listę użytkowników
  user:reset-password     Zresetuj hasło użytkownika
  db:seed                 Załaduj dane do bazy (demo)
  help                    Wyświetl tę pomoc

Examples:
  php cli.php user:create
  php cli.php user:list
  php cli.php user:reset-password admin

USAGE;
}
