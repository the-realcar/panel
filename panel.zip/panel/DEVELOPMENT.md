# DEVELOPMENT - Poradnik dla developerów

## Quick Start

```bash
# 1. Sklonuj i przejdź do katalogu
git clone https://github.com/the-realcar/panel.git
cd panel

# 2. Ustaw .env
cp .env.example .env
# Edytuj .env z danymi do bazy danych

# 3. Załaduj bazę danych
psql -U panel_user -d panel_firmakot -f database/schema.sql
psql -U panel_user -d panel_firmakot -f database/seeds.sql

# 4. Uruchom serwer
php -S localhost:8000

# 5. Zaloguj się
# http://localhost:8000
# admin / password123
```

## Struktura katalogów

```
panel/
├── admin/                 # Legacy widoki panelu admin
├── app/
│   ├── Controllers/       # Logika aplikacji
│   ├── Models/            # Modele ORM-like
│   ├── Views/             # Szablony HTML
│   ├── Core/              # Klasy bazowe (Controller, View)
│   └── bootstrap.php      # Autoloader
├── config/                # Konfiguracja
│   ├── config.php         # Główna konfiguracja
│   ├── database.php       # Połączenie DB
│   └── session.php        # Sesje
├── core/                  # Klasy wsparcia
│   ├── Auth.php           # Autentykacja
│   ├── Database.php       # Wrapper PDO
│   ├── RBAC.php           # Access control
│   └── Validator.php      # Walidacja
├── database/              # Skrypty SQL
│   ├── schema.sql         # Schemat tabel
│   └── seeds.sql          # Dane testowe
├── driver/                # Legacy widoki kierowcy
├── includes/              # Helper functions
│   ├── functions.php      # Funkcje pomocnicze
│   ├── header.php         # Nagłówek
│   ├── footer.php         # Stopka
│   └── navigation.php     # Nawigacja
├── public/
│   ├── api/               # REST API endpointy
│   │   ├── users.php
│   │   ├── vehicles.php
│   │   └── ...
│   ├── assets/            # Zasoby (CSS, JS)
│   │   ├── css/
│   │   ├── js/
│   │   └── images/
│   └── (pozostałe widoki)
├── oauth/                 # OAuth logowanie
├── logs/                  # Logi aplikacji
├── sessions/              # Sesje użytkowników (gitignored)
├── cli.php                # Command-line interface
├── .env.example           # Template zmiennych
├── Makefile               # Przydatne komendy
└── README.md              # Dokumentacja

```

## Database Schema

Główne tabele:

```
users
├── id
├── username (UNIQUE)
├── email (UNIQUE)
├── password_hash
├── first_name
├── last_name
├── active (default: true)
├── discord_id
├── roblox_id
└── timestamps

roles
├── id
├── name
├── description
├── permissions (JSON)

user_roles
├── user_id
├── role_id
└── assigned_date

positions
├── id
├── name
├── description
├── position_limit
├── parent_position_id (hierarchical)

user_positions
├── user_id
├── position_id
└── active

vehicles
├── id
├── registration_number
├── type
├── model
├── seating_capacity

lines
├── id
├── line_number
├── name
├── description

schedules
├── id
├── user_id
├── vehicle_id
├── line_id
├── schedule_date
├── start_time
├── end_time

incidents
├── id
├── user_id
├── vehicle_id
├── title
├── description
├── severity
├── status
└── created_at
```

## Przydatne komendy

### Makefile (jeśli zainstalowany)

```bash
make help              # Pokaż dostępne komendy
make setup             # Przygotuj projekt
make dev               # Uruchom serwer dev
make lint              # Sprawdź błędy PHP
make user-create       # Utwórz użytkownika
make user-list         # Wyświetl użytkowników
```

### CLI (php cli.php)

```bash
php cli.php user:create          # Nowy użytkownik
php cli.php user:list            # Lista użytkowników
php cli.php user:reset-password  # Reset hasła
```

### PHP Server

```bash
# Port 8000
php -S localhost:8000

# Custom port
php -S localhost:9000

# Określ root directory
php -S localhost:8000 -t public
```

### Database (psql)

```bash
# Zaloguj się
psql -U panel_user -d panel_firmakot

# Backupy
pg_dump -U panel_user -d panel_firmakot > backup.sql
psql -U panel_user -d panel_firmakot < backup.sql
```

### API Testing

```bash
# Login
curl -c cookies.txt -X POST http://localhost:8000/login.php \
  -d "username=admin&password=password123"

# Test API
curl -b cookies.txt http://localhost:8000/public/api/users.php | jq

# Pretty print JSON
curl -b cookies.txt http://localhost:8000/public/api/users.php | jq '.'
```

## Dodawanie nowej funkcjonalności

### Nowy API Endpoint

1. Utwórz plik `public/api/your-resource.php`
2. Dodaj template z [API.md](API.md) - sekcja "API Endpoints"
3. Zaimplementuj logikę
4. Zaktualizuj [API.md](API.md) dokumentację

### Nowy Model

1. Utwórz plik `app/Models/YourModel.php`
2. Dodaj statyczne metody (find, findAll, create, update, delete)
3. Używaj `Database` klasy do zapytań

### Nowy Kontroler

1. Utwórz plik `app/Controllers/YourController.php`
2. Rozszerz `Controller` lub dodaj własne metody
3. Sprawdzaj uprawnienia z `RBAC`

### Nowy View (szablon)

1. Utwórz plik w `app/Views/...`
2. Używaj funkcji `e()` do escapowania
3. Używaj `csrfField()` w formularzach

## Debugowanie

### Tryb Development

```php
// W .env
APP_ENV=development

// W config/config.php
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}
```

### Error Logs

```bash
# Obserwuj logi
tail -f logs/error.log

# Czy logi istnieją?
ls -la logs/
```

### SQL Debugging

```php
// Dodaj logging w Database.php
error_log("SQL: " . $sql);
error_log("Params: " . json_encode($params));
```

### Tymczasowe var_dump

```php
// NIE rób tego w produkcji!
if (APP_ENV === 'development') {
    var_dump($data);
    die();
}
```

## Testing

### PHP Linting

```bash
# Test jeden plik
php -l app/Controllers/MyController.php

# Test cały projekt
find . -name "*.php" -type f | xargs php -l
```

### Manual Testing

1. **CRUD Operations**
   - Utwórz, odczytaj, aktualizuj, usuń

2. **Authorization**
   - Test z różnymi rolami

3. **API Endpoints**
   - Test z curl/Postman

4. **Edge Cases**
   - Puste dane
   - Bardzo duże dane
   - Znaki specjalne

## Performance Tips

1. **Query Optimization**
   - Używaj indexes w DB
   - Unikaj N+1 queries

2. **Caching**
   - Cacheuj dane statyczne
   - localStorage dla klienta

3. **Database**
   - Prepared statements (już robisz)
   - Limity paginacji

4. **Frontend**
   - Minify CSS/JS
   - Lazy loading obrazów

## Narzędzia

### Recommended

- **IDE**: VS Code (rozszerzenia: PHP Intellisense, REST Client)
- **Tools**: 
  - Postman - API testing
  - DBeaver - Database management
  - Git Desktop - Version control
  - Docker - Database containerization

### VS Code Extensions

```json
{
  "recommendations": [
    "bmewburn.vscode-intelephense-client",
    "ms-vscode.live-server",
    "humao.rest-client",
    "eamodio.gitlens"
  ]
}
```

## Security Notes

- Zawsze waliduj input na serwerze
- Nie pokazuj szczegóły błędów w produkcji
- Loguj wszystkie operacje krytyczne
- Regularnie aktualizuj zależności
- Skanuj kod na vulnerabilities

## Zasoby

- [PHP Best Practices](https://www.php-fig.org/)
- [PostgreSQL Docs](https://www.postgresql.org/docs/)
- [OWASP Security](https://owasp.org/)
- [MDN Web Docs](https://developer.mozilla.org/)

## Problem Solving

### Problem: "Command not found: php"
**Rozwiązanie**: Zainstaluj PHP lub dodaj do PATH

### Problem: "CORS error"
**Rozwiązanie**: Set proper headers w API (obecnie same JSON)

### Problem: "Database connection refused"
**Rozwiązanie**: Sprawdź czy PostgreSQL działa, credentials w .env

### Problem: "Permission denied" na logs/
**Rozwiązanie**: `chmod 755 logs sessions`

---

Happy coding! 🚀

Ostatnia aktualizacja: 2026-03-04
